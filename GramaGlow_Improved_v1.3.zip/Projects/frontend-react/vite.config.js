import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({ base: '/react-dist/', plugins: [react()], server: { port: 5173, proxy: { '/api': 'http://localhost:3000' } }, build: { outDir: '../public/react-dist', emptyOutDir: true } });
